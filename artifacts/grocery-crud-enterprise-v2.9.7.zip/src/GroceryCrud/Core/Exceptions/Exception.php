<?php
namespace GroceryCrud\Core\Exceptions;

class Exception extends \Exception {

}